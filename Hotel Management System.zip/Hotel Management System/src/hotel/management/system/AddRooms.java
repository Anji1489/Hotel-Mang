
package hotel.management.system;

import java.awt.Color;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class AddRooms extends JFrame implements ActionListener {

    JButton submit,cancel;
    JComboBox cbbox,typeCombo,cleanCombo;
    JTextField tfroom,tfprice;
     AddRooms() {
        
        getContentPane().setBackground(Color.getHSBColor(23.0f, 25.0f, 26.0f));
        setLayout(null);
        JLabel heading=new JLabel("Add Rooms");
        heading.setFont(new Font("Tohoma",Font.BOLD,18));
        heading.setBounds(150, 20, 200, 20);
        add(heading);
        
        JLabel lblroomno=new JLabel("Room Number");
        lblroomno.setFont(new Font("Tohoma",Font.PLAIN,16));
        lblroomno.setBounds(60, 80,120 , 30);
        add(lblroomno);
        
        tfroom=new JTextField();
        tfroom.setBounds(200,80 , 150, 30);
        tfroom.setFont(new Font("times-new roman",Font.PLAIN,15));
        add(tfroom);
        
        JLabel lblavailabe=new JLabel("Available");
        lblavailabe.setFont(new Font("Tohoma",Font.PLAIN,16));
        lblavailabe.setBounds(60, 130,120 , 30);
        add(lblavailabe);
        
        String availableOptions[]={"Available","Occupied"};
         cbbox=new JComboBox(availableOptions);
        cbbox.setBounds(200, 130, 150, 30);
        cbbox.setBackground(Color.white);
        add(cbbox);
        
        JLabel lblcleaning=new JLabel("Cleaning Status");
        lblcleaning.setFont(new Font("Tohoma",Font.PLAIN,16));
        lblcleaning.setBounds(60, 180,120 , 30);
        add(lblcleaning);
        
        String cleaningOptions[]={"Cleaned","Dirty"};
         cleanCombo=new JComboBox(cleaningOptions);
        cleanCombo.setBounds(200, 180, 150, 30);
        cleanCombo.setBackground(Color.white);
        add(cleanCombo);
        
        JLabel lblprice=new JLabel("Price");
        lblprice.setFont(new Font("Tohoma",Font.PLAIN,16));
        lblprice.setBounds(60, 230,120 , 30);
        add(lblprice);
        
        tfprice=new JTextField();
        tfprice.setBounds(200,230 , 150, 30);
        tfprice.setFont(new Font("times-new roman",Font.PLAIN,15));
        add(tfprice);
        
        
        JLabel lbltype=new JLabel("Bed Type");
        lbltype.setFont(new Font("Tohoma",Font.PLAIN,16));
        lbltype.setBounds(60, 280,120 , 30);
        add(lbltype);
        
        String typeOptions[]={"Single Bed","Double Bed"};
         typeCombo=new JComboBox(typeOptions);
        typeCombo.setBounds(200, 280, 150, 30);
        typeCombo.setBackground(Color.white);
        add(typeCombo);
        
        
         submit=new JButton("Add Room");
        submit.setBackground(Color.black);
        submit.setForeground(Color.white);
        submit.setBounds(60,330,100,30);
        submit.addActionListener(this);
        add(submit);
        
         cancel=new JButton("Cancel");
        cancel.setBackground(Color.black);
        cancel.setForeground(Color.white);
        cancel.setBounds(220,330,100,30);
        cancel.addActionListener(this);
        add(cancel);
        
        
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/twelve.jpg"));
        JLabel image=new JLabel(i1);
        image.setBounds(400, 30, 500, 300);
        add(image);
        
        
        
        
        setBounds(330, 200, 940, 470);
        setVisible(true);
        
    }
     public void actionPerformed(ActionEvent ae){
         
         if(ae.getSource()==submit){
             
             String roomNumber=tfroom.getText();
             String availability=(String)cbbox.getSelectedItem();
             String status=(String) cleanCombo.getSelectedItem();
             String price=tfprice.getText();
             String type=(String)typeCombo.getSelectedItem();
             
             try{
                 Conn conn=new Conn();
                 String query="Insert into room values('"+roomNumber+"','"+availability+"','"+status+"','"+price+"','"+type+"')";
                 conn.s.executeUpdate(query);
                 JOptionPane.showMessageDialog(null, "ROOM ADDED SUCCESSFULLY");
                 setVisible(false);
             }
             catch(Exception e){
                 e.printStackTrace();
             }
             
         }
         else{
             setVisible(false);
             
         }
     }
    
    

    public static void main(String args[]) {
        new AddRooms();
    }
}
