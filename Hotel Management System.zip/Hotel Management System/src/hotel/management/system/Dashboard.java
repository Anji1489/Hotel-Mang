
package hotel.management.system;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

public class Dashboard extends JFrame implements ActionListener{
    
    Dashboard(){
        setBounds(0,0,1550,1000);
        setLayout(null);
        
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/third.jpg"));
        Image i2=i1.getImage().getScaledInstance(1550, 1000, Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel image=new JLabel(i3);
        image.setBounds(0,0,1550,1000);
        add(image);
        
        
        JLabel text=new JLabel("The Sahasra Group Welcomes You");
        text.setBounds(400,80,1000,50);
        text.setFont(new Font("Cursive",Font.PLAIN,46));
        text.setForeground(Color.red);
        image.add(text);
        
        JMenuBar mb=new JMenuBar();
        mb.setBounds(0,0,1550,40);
        mb.setBackground(Color.DARK_GRAY);
        image.add(mb);
        
        JMenu hotel=new JMenu("Sahasra Mangement");
        hotel.setForeground(Color.white);
        hotel.setFont(new Font("Graphik",Font.BOLD,20));
        mb.add(hotel);
        
        JMenuItem reception=new JCheckBoxMenuItem("RECEPTION");
        reception.addActionListener(this);
        hotel.add(reception);
        
        JMenu admin=new JMenu("Admin");
        admin.setForeground(Color.white);
        admin.setFont(new Font("Graphik",Font.BOLD,20));
        mb.add(admin);
        
        JMenuItem addemploye=new JMenuItem("ADD EMPLOYEE");
        addemploye.addActionListener(this);
        admin.add(addemploye);
        
        JMenuItem addRoom=new JMenuItem("ADD ROOMS");
        addRoom.addActionListener(this);
        admin.add(addRoom);
        
        JMenuItem addDriver=new JMenuItem("ADD DRIVERS");
        addDriver.addActionListener(this);
        admin.add(addDriver);
        
        
        setVisible(true);
        
        
    }
    public void actionPerformed(ActionEvent e){
        if(e.getActionCommand().equals("ADD EMPLOYEE")){
            new AddEmployee();
            setVisible(false);
        }
        else if(e.getActionCommand().equals("ADD ROOMS")){
            new AddRooms();
            setVisible(false);
        }
        
        else if(e.getActionCommand().equals("ADD DRIVERS")){
            new AddDrivers();
        }
        
        else if(e.getActionCommand().equals("RECEPTION")){
            new Reception();
        }
        
        
        
        
        
        
    }
    
    
    
    public static void main(String args[]){
        new Dashboard();
    }
}
