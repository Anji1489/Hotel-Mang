
package hotel.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class AddEmployee extends JFrame implements ActionListener{

    JTextField tfname,tfage,tfsalary,tfphone,tfemail,tfaadhar;
    JRadioButton rbmale,rbfemale;
    JComboBox cbjob;
    AddEmployee(){
        setLayout(null);
        
        getContentPane().setBackground(new Color(0, 0, 0)); 
        getContentPane().setForeground(new Color(255,255,255));
        Font labelFont = new Font("Tahoma", Font.BOLD, 16);
        Font textFieldFont = new Font("Tahoma", Font.PLAIN, 14);
        



        
       
       
        
        
        
        JLabel lblname=new JLabel("NAME");
        lblname.setBounds(60,30,120,30);
        lblname.setFont(new Font("sans-serif",Font.BOLD,17));
        lblname.setFont(labelFont);
        lblname.setForeground(Color.WHITE);
        add(lblname);
        
         tfname=new JTextField();
        tfname.setBounds(200,30,150,30);
        tfname.setFont(textFieldFont);
        add(tfname);
        
        JLabel lblage=new JLabel("AGE");
        lblage.setBounds(60,80,120,30);
        lblage.setFont(new Font("sans-serif",Font.BOLD,17));
        lblname.setFont(labelFont);
        add(lblage);
        
         tfage=new JTextField();
        tfage.setBounds(200,80,150,30);
        tfage.setFont(textFieldFont);
        add(tfage);
        
         JLabel lblgender=new JLabel("GENDER");
        lblgender.setBounds(60,130,120,30);
        lblgender.setFont(new Font("sans-serif",Font.BOLD,17));
        add(lblgender);
        
        rbmale=new JRadioButton("MALE");
        rbmale.setBounds(200,130,70,30);
        rbmale.setFont(new Font("Tahoma",Font.PLAIN,14));
        rbmale.setBackground(Color.WHITE);
        add(rbmale);
        
        rbfemale=new JRadioButton("FEMALE");
        rbfemale.setBounds(280,130,90,30);
        rbfemale.setFont(new Font("Tahoma",Font.PLAIN,14));
        rbfemale.setBackground(Color.WHITE);
        add(rbfemale);
        
        ButtonGroup bg=new ButtonGroup();
        bg.add(rbmale);
        bg.add(rbfemale);
        
        JLabel lbljob=new JLabel("JOB");
        lbljob.setBounds(60,180,120,30);
        lbljob.setFont(new Font("sans-serif",Font.BOLD,17));
        add(lbljob);
        
        String str[]={"Front end desk","Porters","House-Keeping","Kitchen Staff","Room service","Chefs","Waiter","Manager","Accountant"};
        cbjob=new JComboBox(str);
        cbjob.setBounds(200,180,150,30);
        cbjob.setBackground(Color.white);
        add(cbjob);
        
        JLabel lbsalary=new JLabel("SALARY");
        lbsalary.setBounds(60,230,120,30);
        lbsalary.setFont(new Font("sans-serif",Font.BOLD,17));
        add(lbsalary);
        
        tfsalary=new JTextField();
        tfsalary.setBounds(200,230,150,30);
        tfsalary.setFont(textFieldFont);
        add(tfsalary);
        
        JLabel lbphone=new JLabel("PHONE");
        lbphone.setBounds(60,280,120,30);
        lbphone.setFont(new Font("sans-serif",Font.BOLD,17));
        add(lbphone);
        
        tfphone=new JTextField();
        tfphone.setBounds(200,280,150,30);
        tfphone.setFont(textFieldFont);
        add(tfphone);
        
         JLabel lbemail=new JLabel("EMAIL");
        lbemail.setBounds(60,330,120,30);
        lbemail.setFont(new Font("sans-serif",Font.BOLD,17));
        add(lbemail);
        
        tfemail=new JTextField();
        tfemail.setBounds(200,330,150,30);
        tfemail.setFont(textFieldFont);
        add(tfemail);
        
        JLabel lbaadhar=new JLabel("AADHAR");
        lbaadhar.setBounds(60,380,120,30);
        lbaadhar.setFont(new Font("sans-serif",Font.BOLD,17));
        add(lbaadhar);
        
        tfaadhar=new JTextField();
        tfaadhar.setBounds(200,380,150,30);
        tfaadhar.setFont(textFieldFont);
        add(tfaadhar);
        
        JButton submit=new JButton("SUBMIT");
        submit.setBounds(150,430,120,30);
        submit.setBackground(Color.LIGHT_GRAY);
        submit.addActionListener(this);
        submit.setForeground(Color.red);
        add(submit);
        
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/sixth.jpg"));
        JLabel image=new JLabel(i1);
        image.setBounds(240, 500, 970, 430);
        add(image);
               
        
        
        
        
        
        setBounds(350,200,850,540);
        setVisible(true);
        
    }
    public void actionPerformed(ActionEvent e){
        String name=tfname.getText();
        String age=tfage.getText();
        String salary=tfsalary.getText();
        String phone=tfphone.getText();
        String email=tfemail.getText();
        String aadhar=tfaadhar.getText();
        
        String gender=null;
        
        if(name.equals("")){
            JOptionPane.showMessageDialog(null, "NAME SHHOULD NOT BE EMPTY");
            return;
        }
        if(email.equals("")&& email.contains("@")){
            JOptionPane.showMessageDialog(null, "GIVE VALID EMAIL AND IT CONTAINS (@) AND (.COM)");
            return;
        }
        if(rbmale.isSelected()){
            gender="Male";
        
        }
        else if(rbfemale.isSelected()){
            gender="Female";
        
        }
        
        String job=(String)cbjob.getSelectedItem();
        
        try{
            
            Conn conn=new Conn();
            
            String query="insert into employee values('"+name+"','"+age+"','"+gender+"','"+job+"','"+salary+"','"+phone+"','"+email+"','"+aadhar+"')";
            conn.s.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "EMPLOYEE ADDED SUCCSSFULLY");
            
            setVisible(false);
            
            
        }
        catch(Exception ae){
            ae.printStackTrace();
        }
    }
    
    
    
    
    
    public static void main(String args[]) {
        new AddEmployee();
    }
}
