
package hotel.management.system;


import java.awt.*;
import javax.swing.*;

public class Demo extends JFrame{
    Demo(){
        getContentPane().setBackground(Color.white);
        setLayout(null);
        JLabel name=new JLabel("HEading");
        name.setBounds(194, 10, 120, 22);
        add(name);
        name.setFont(new Font("sans-serif",Font.ITALIC,16));
        
        setBounds(300, 500, 1200, 400);
        setVisible(true);
    }
 
    public static void main(String args[]){
        new Demo();
    }
}
